package com.rabbitmqexample.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rabbitmqexample.model.Patient;
import com.rabbitmqexample.service.PatientService;

@RestController
public class PatientController {

	@Autowired
	PatientService patientService;
	
	@GetMapping("/hello")
	public String sayHello() {
		return "Hello World!";
	}
	
	@GetMapping("/send-message")
	public ResponseEntity<Patient> sendMessage() {
		Patient patient = new Patient();
		patient.setPatientId((int) Math.random());
		patient.setHeart_rate((int) (Math.random()));
		
		patientService.produceAndSendMessage(patient);
		return new ResponseEntity<>(patient,HttpStatus.OK);
	}
}
