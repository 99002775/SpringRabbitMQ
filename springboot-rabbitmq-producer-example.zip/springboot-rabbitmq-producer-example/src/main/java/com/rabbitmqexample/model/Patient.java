package com.rabbitmqexample.model;

import java.io.Serializable;

public class Patient implements Serializable{

	private static final long serialVersionUID = 1L;
	
	
	private Integer PatientId;
	private Integer Heart_rate;
	private Integer Blood_pressure;
	
	
	
	
	public Integer getBlood_pressure() {
		return Blood_pressure;
	}




	public void setBlood_pressure(Integer blood_pressure) {
		Blood_pressure = blood_pressure;
	}




	public Integer getPatientId() {
		return PatientId;
	}




	public void setPatientId(Integer patientId) {
		PatientId = patientId;
	}




	public Integer getHeart_rate() {
		return Heart_rate;
	}




	public void setHeart_rate(Integer heart_rate) {
		Heart_rate = heart_rate;
	}




	@Override
	public String toString() {
		return "Patient [PatientId=" + PatientId + ", Heart_rate=" + Heart_rate + ", Blood_pressure=" + Blood_pressure
				+ "]";
	}




//	@Override
//	public String toString() {
//		return "Patient [PatientId=" + PatientId + ", Heart_rate=" + Heart_rate + "]";
//	}




	
	
	
}
