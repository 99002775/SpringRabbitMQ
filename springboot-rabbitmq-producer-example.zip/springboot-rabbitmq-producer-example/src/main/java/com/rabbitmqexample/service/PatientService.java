package com.rabbitmqexample.service;

import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;


import com.rabbitmqexample.model.Patient;

@Service
public class PatientService {

	
	@Autowired
	private AmqpTemplate amqpTemplate;
	
	@Value("${Heart_rate.rabbitmq.exchange}")
	private String exchange;
	
	@Value("${Heart_rate.rabbitmq.routingkey}")
	private String routingKey;
	@Value("${Blood_pressure.rabbitmq.exchange1}")
	private String exchange1;
	
	@Value("${Blood_pressure.rabbitmq.routingkey1}")
	private String routingKey1;
	
	
	public void produceAndSendMessage(Patient patient){
		amqpTemplate.convertAndSend(exchange, routingKey, patient);
		System.out.println("Send msg = " +patient);
	}
	public void produceAndSendMessage1(Patient patient){
		amqpTemplate.convertAndSend(exchange1, routingKey1, patient);
		System.out.println("Send msg = " +patient);
	}
	@Scheduled(fixedDelay = 3000L)
	public void sendScheduleMessage(){
		Patient patient = new Patient();
		int min=1;
		int max=50;
		patient.setPatientId((int) (Math.random()* ( max - min )) + min );
		int minhr=70;
		int maxhr=90;
		patient.setHeart_rate((int) (Math.random()*(maxhr-minhr))+minhr);
		
		amqpTemplate.convertAndSend(exchange, routingKey,patient);
		System.out.println("Send Message = " + patient);
	}
	@Scheduled(fixedDelay = 3000L)
	public void sendScheduleMessage1(){
		Patient patient = new Patient();
		int min=1;
		int max=50;
		patient.setPatientId((int) (Math.random()* ( max - min )) + min );
		int minbp=70;
		int maxbp=90;
		patient.setBlood_pressure((int) (Math.random()*(maxbp-minbp))+minbp);
		
		amqpTemplate.convertAndSend(exchange, routingKey1,patient);
		System.out.println("Send Message = " + patient);
	}
}
