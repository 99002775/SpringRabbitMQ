package com.rabbitmqexample.config;

import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


@Configuration
public class RabbitMQConfig {

	@Value("${Heart_rate.rabbitmq.queue}")
	String queueName;

	@Value("${Heart_rate.rabbitmq.exchange}")
	String exchange;

	@Value("${Heart_rate.rabbitmq.routingkey}")
	private String routingkey;
	@Value("${Blood_pressure.rabbitmq.queue}")
	String queueName1;

	@Value("${Blood_pressure.rabbitmq.exchange1}")
	String exchange1;

	@Value("${Blood_pressure.rabbitmq.routingkey1}")
	private String routingkey1;


	@Bean
	Queue queue() {
		return new Queue(queueName, false);
	}
	@Bean
	Queue queue1() {
		return new Queue(queueName1, false);
	}

	@Bean
	DirectExchange exchange() {
		return new DirectExchange(exchange);
	}

	@Bean
	Binding binding(Queue queue, DirectExchange exchange) {
		//routingKey same as binding key
		return BindingBuilder.bind(queue).to(exchange).with(routingkey);
	}
	@Bean
	Binding binding1(Queue queue, DirectExchange exchange) {
		//routingKey same as binding key
		return BindingBuilder.bind(queue).to(exchange).with(routingkey1);
	}
	@Bean
	public MessageConverter jsonMessageConverter() {
		return new Jackson2JsonMessageConverter();
	}

	@Bean
	public AmqpTemplate rabbitTemplate(ConnectionFactory connectionFactory) {
		final RabbitTemplate rabbitTemplate = new RabbitTemplate(connectionFactory);
		rabbitTemplate.setMessageConverter(jsonMessageConverter());
		return rabbitTemplate;
	}
}